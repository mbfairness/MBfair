package generators;

import java.util.Arrays;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;


import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;


public class GenerateMetrics {
	public static void main(String   argv[]) throws IOException{
		
        /**************************************************************************************/
        /* This part is part of future work to enable reading dataset provided as excel file  */
        /**************************************************************************************/
		
		
		
		
	      try {	
	    	  
	          String xmlPath = "src/generators";
	          File inputFile = new File(xmlPath+"\\bankSystemLargerModel.xml"); //read a UML Model as .xml file
	         
	         
	         // initiate parser 
	         DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance(); 
	         DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
	         Document doc = dBuilder.parse(inputFile);
	         doc.getDocumentElement().normalize();
	         	         
	         

	  
	 
		    /**************************************************************************************/
		    /*           Map sensitive decisions with their corresponding classifiers             */
		    /**************************************************************************************/
	 		
	 		
	         NodeList basedClassifierList = doc.getElementsByTagName("UMLFairness:indvidualFairness"); // retrieve all the <individualFairness>-annotated elements
	         
	         String metric="";
	         String threshold="";
	         // Now we iterate over all retrieved behavior classifiers 
	         for (int temp = 0; temp < basedClassifierList.getLength(); temp++) {

	     		Node basedClassifierNode = basedClassifierList.item(temp);
	     				
	     		
	     		if (basedClassifierNode.getNodeType() == Node.ELEMENT_NODE) {

	    			Element eElement = (Element) basedClassifierNode;
                  
	    			metric= eElement.getAttribute("metric"); // return the name  of the correlation metric
	    			
	    			threshold= eElement.getAttribute("threshold"); // return the value of the threshold
	    			
	   	           
                    
	    			
	    		}
	    	}
	         
	         
	         NodeList packages = doc.getElementsByTagName("packagedElement");// return all element of type packagedElement
	        // HashMap<String, List<String>> classifiersAttributes = new HashMap<String, List<String>>();
	         HashMap<String, String> mapClassIDName = new HashMap<String, String>();


	         //Now iterate over the packages
	         for (int x = 0; x < packages.getLength(); x++) {

		     		Node packageNode = packages.item(x); // get a package element node
		     				
		     		
		     		if (packageNode.getNodeType() == Node.ELEMENT_NODE) {

		    			Element eElement = (Element) packageNode; // Caste package node to element
	                     
		    			//Check if package element of type UML class
		    			if(eElement.getAttribute("xmi:type").equals("uml:Class"))
		    			{
			    			String classifierID=eElement.getAttribute("classifierBehavior");// return the classifierBehavior id of the class
			    			String cID=eElement.getAttribute("xmi:id");
			    			String cName=eElement.getAttribute("name");
			    			mapClassIDName.put(cID, cName);
		    			}
		    			
		     		}
	         }
	         
	         
		     		
		    NodeList pList = doc.getElementsByTagName("UMLFairness:critical"); // define a list for storing the critical annotations.
	         HashMap<String, List<String>> mapClassCriticalData = new HashMap<String, List<String>>();

   	         List<String> protectedList = new ArrayList<String>(); // define a list for storing  the protected data.
   	         String className="";
	         
	         for (int temp = 0; temp < pList.getLength(); temp++) {

	     		Node pNode = pList.item(temp);
	     				
	     		
	     		if (pNode.getNodeType() == Node.ELEMENT_NODE) {


	    			Element eElement = (Element) pNode;
	    			
	    			String basedStructureClass=eElement.getAttribute("base_StructuredClassifier"); // get the id of the critical-annotated class
                     
	    			String prot=eElement.getElementsByTagName("protectedData").item(0).getTextContent(); // get the protected data from the attributes of the critical stereotype.
	    			
	    			Pattern pattern = Pattern.compile("\\w+");
	    			Matcher matcher = pattern.matcher(prot);
	    			while (matcher.find()) {
	    				protectedList.add(matcher.group());
	    			}
	    			
	    			
	    		   className=mapClassIDName.get(basedStructureClass);
	    				    			
	    			
	    		}
	    	}
	         
		         
	            FileWriter writer = new FileWriter("correlation.txt"); 
	            writer.write("Metric: "+metric+System.lineSeparator());
	            writer.write("Threshold: "+threshold+System.lineSeparator());
	            writer.write("Data Table: "+className+System.lineSeparator());
	            writer.write("Protected Data of "+className+":"+System.lineSeparator());

	            for (int p = 0; p < protectedList.size(); p++) {

		            writer.write(protectedList.get(p)+System.lineSeparator());

	            }
		     		
		  	
	            writer.write("End of Protected list"+System.lineSeparator());
	            writer.close();
	            
	            System.out.println("Successfully generated");

	      } catch (Exception e) {
	         e.printStackTrace();
	      }
	   }
	}


